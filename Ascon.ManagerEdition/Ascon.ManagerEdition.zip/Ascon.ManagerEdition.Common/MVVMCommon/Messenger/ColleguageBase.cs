﻿namespace Ascon.ManagerEdition.Common.MVVMCommon.Messenger
{
    public abstract class ColleguageBase
    {
        public virtual void Notify(object message) { }
    }
}