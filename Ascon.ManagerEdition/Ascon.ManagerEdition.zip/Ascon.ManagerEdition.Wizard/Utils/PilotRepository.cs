﻿using Ascon.ManagerEdition.Common.DICommon;
using Ascon.ManagerEdition.Wizard.Models;
using Ascon.Pilot.SDK;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ascon.ManagerEdition.Wizard.Utils
{
    public class PilotRepository: IPilotRepository
    {
        private IObjectModifier _modifer => NinjectCommon.Kernel.Get<IObjectModifier>();

        private IFileProvider _fileProvider => NinjectCommon.Kernel.Get<IFileProvider>();

        private IObjectsRepository _repository => NinjectCommon.Kernel.Get<IObjectsRepository>();

        public void ChangedAccess(Guid id, IAccessRecord accessRecord)
        {
            try
            {
                var builder = _modifer.EditById(id);
                builder.SetAccessRights(accessRecord.OrgUnitId, accessRecord.Access.AccessLevel, accessRecord.Access.ValidThrough, accessRecord.Access.IsInheritable);
                _modifer.Apply();
            }
            catch (Exception e)
            {
                string a = e.Message;
            }
        }

        public IAccessRecord GetAccessRecord(string orgUnit, AccessLevel access)
        {
            var accessRecord = new AccessRecord();

            var firstOrDefault = _repository
                .GetOrganisationUnits()
                .FirstOrDefault(x => x.Title == orgUnit);

            if (firstOrDefault != null)
                accessRecord.OrgUnitId = firstOrDefault.Id;

            accessRecord.Access = new Access() { AccessLevel = access };

            return accessRecord;
        }

        public IAccessRecord GetAccessRecord(IAccessRecord accessRecord, AccessLevel access)
        {
            var _accessRecord = new AccessRecord();

            _accessRecord.InheritanceSource = accessRecord.InheritanceSource;
            _accessRecord.OrgUnitId = accessRecord.OrgUnitId;
            _accessRecord.RecordOwner = accessRecord.RecordOwner;

            _accessRecord.Access = new Access() { AccessLevel = access, IsInheritable = accessRecord.Access.IsInheritable };

            return _accessRecord;
        }

        public IDataObject CreateNewRedaction(Guid parentId, IType type, string cipherName, string cipherValue)
        {
            try
            {
                var builder = _modifer.CreateById(Guid.NewGuid(), parentId, type);
                
                if (builder != null)
                    builder.SetAttribute(cipherName, cipherValue);

                _modifer.Apply();
                return builder.DataObject;
            }
            catch (Exception e)
            {
                string a = e.Message;
                return null;
            }
        }

        public Task CreateAsync(List<ProjectSection> objects, Guid parentId)
        {
            return Task.Factory.StartNew(() =>
            {
                if (objects == null || !objects.Any())
                    return;

                CreateRecursive(objects, parentId);
                _modifer?.Apply();
            });
        }

        public void CreateAsync(ProjectSection objects)
        {
             if (objects == null)
                    return;
             CreateObject(objects);
             _modifer?.Apply();
            
        }

        private void CreateRecursive(List<ProjectSection> objects, Guid parentId)
        {
            var children = objects.FindAll(o => o.ParentId == parentId);

            if (!children.Any())
                return;

            foreach (var child in children)
            {
                if (CreateObject(child))
                    CreateRecursive(objects, child.Id);
            }
        }

        private bool CreateObject(ProjectSection obj)
        {
            try
            {
                var type = _repository.GetType(obj.Type);
                var builder = _modifer.CreateById(obj.Id, obj.ParentId, type);

                //атрибуты
                if (obj.Attributes.Any())
                {
                    foreach (var attribute in obj.Attributes)
                    {
                        try
                        {
                            builder.SetAttribute(attribute.Key, attribute.Value.ToString());
                        }
                        catch { }

                    }
                }

                if (obj.Files.Any())
                {
                    foreach (var file in obj.Files)
                    {
                        try
                        {
                            var stream = _fileProvider.OpenRead(file);
                            builder.AddFile(file.Name, stream, file.Created, file.Accessed, file.Modified);
                        }
                        catch (Exception e) { var a = e.Message; }
                    }
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
