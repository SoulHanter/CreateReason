﻿using Ascon.Pilot.SDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ascon.ManagerEdition.Wizard.Utils
{
    public interface IPilotRepository
    {
        void ChangedAccess(Guid id, IAccessRecord accessRecord);
    }
}
