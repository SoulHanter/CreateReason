﻿using Ascon.ManagerEdition.Common.MVVMCommon.Converters;
using Ascon.ManagerEdition.Wizard.Converter;
using Ascon.ManagerEdition.Wizard.Models;
using Ascon.Pilot.SDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ascon.ManagerEdition.Wizard.Utils
{
    public static class DataObjectExtensions
    {
        public static ProjectSection MapToProjectSection(this IDataObject source)
        {
            if (source == null)
                return null;

            return new ProjectSection
            {
                Id = source.Id,
                Name = source.DisplayName,
                ParentId = source.ParentId,
                Type = source.Type.Id,
                Attributes = source.Attributes, 
                RelatedSourceFiles = source.RelatedSourceFiles,
                Files = source.Files,
                ActualFileSnapshot = source.ActualFileSnapshot.MapToFileSnapshot()

            };
        }

        public static FilesSnapshot MapToFileSnapshot(this IFilesSnapshot source)
        {
            return new FilesSnapshot
            {
                Created = source.Created,
                CreatorId = source.CreatorId,
                Reason = source.Reason,
                Files = source.Files
            };
        }

        public static File MapToFile(this IFile source)
        {
            return new File
            {
                Accessed = source.Accessed,
                Created = source.Created,
                Id = source.Id,
                Md5 = source.Md5,
                Modified = source.Modified,
                Name = source.Name,
                Size = source.Size
            };
        }



        public static TableRemarksModel MapToRemark(this IDictionary<string, object> source, Guid id, Guid parentId, RemarkFile remarkFile)
        {
            TableRemarksModel result = new TableRemarksModel() { Id = id, ParentId = parentId };

            result.FromUser    = source.ContainsKey(remarkFile.FromUser)    ? source[remarkFile.FromUser]?.ToString()    : null;
            result.ToUser      = source.ContainsKey(remarkFile.ToUser)      ? source[remarkFile.ToUser]?.ToString()      : null;
            result.Description = source.ContainsKey(remarkFile.Description) ? source[remarkFile.Description]?.ToString() : null;
            result.Enlargement = source.ContainsKey(remarkFile.Enlargement) ? source[remarkFile.Enlargement]?.ToString() : null;
            result.Document    = source.ContainsKey(remarkFile.Document)    ? source[remarkFile.Document]?.ToString()    : null;
            result.Commit      = source.ContainsKey(remarkFile.Commit)      ? source[remarkFile.Commit]?.ToString()      : null;
            result.Statement   = source.ContainsKey(remarkFile.Statement)   ? int.Parse(source[remarkFile.Statement]?.ToString() ?? "0")  == 1    : false;

            if (source.ContainsKey(remarkFile.Act))
            {
                result.Act = source[remarkFile.Act].ToString().MapToAct();
            }

            if (result.Statement)
            {
                switch (result.Act)
                {
                    case Acts.FINALIZE: result.Color = ColorsRow.GREEN;
                        break;
                    case Acts.DEVELOP: result.Color = ColorsRow.GREEN;
                        break;
                    case Acts.EXCLUDE: result.Color = ColorsRow.RED;
                        break;
                    case Acts.DISMISS: result.Color = ColorsRow.YELLOW;
                        break;
                }
            }
            else
                result.Color = ColorsRow.NONE;
            

            return result;
        }
    }
}
