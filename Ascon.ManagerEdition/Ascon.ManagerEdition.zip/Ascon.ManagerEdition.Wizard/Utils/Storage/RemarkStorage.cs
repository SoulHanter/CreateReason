﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ascon.Pilot.SDK;
using Ascon.ManagerEdition.Common.DICommon;
using Ninject;
using Ascon.ManagerEdition.Wizard.Models;
using System.ComponentModel;
using Ascon.ManagerEdition.Common.PilotIceCommon.Observers;

namespace Ascon.ManagerEdition.Wizard.Utils.Storage
{
    public class RemarkStorage : IRemarkStorage, INotifyPropertyChanged
    {
        private IObjectModifier _modifer => NinjectCommon.Kernel.Get<IObjectModifier>();

        private IObjectsRepository _repository => NinjectCommon.Kernel.Get<IObjectsRepository>();

        public Settings.Settings _settings = NinjectCommon.Kernel.Get<Settings.Settings>();        

        public void CreateRemark(TableRemarksModel obj)
        {
            var builder = _modifer?.CreateById(obj.Id, obj.ParentId, _repository.GetType(_settings.RemarkFile.Type));
            if (builder != null)
            {
                AppendAttribute(obj, builder);
                builder.SetAttribute(_settings.RemarkFile.CurrentUser, _repository.GetCurrentPerson().DisplayName);
                builder.SetAttribute(_settings.RemarkFile.DataCreate, DateTime.Now);
            }
            _modifer?.Apply();
        }

        public void DeleteRemark(TableRemarksModel obj)
        {
            _modifer?.DeleteById(obj.Id);
            _modifer?.Apply();
        }

        public void EditRemark(TableRemarksModel obj)
        {
            var builder = _modifer?.EditById(obj.Id);
            if (builder != null)
            {
                AppendAttribute(obj, builder);
            }
            _modifer?.Apply();
        }

        private void AppendAttribute(TableRemarksModel obj, IObjectBuilder builder)
        {
            var attributes = _settings.RemarkFile;

            try
            {
                builder.SetAttribute(attributes.FromUser, obj.FromUser??"");
                builder.SetAttribute(attributes.ToUser, obj.ToUser ?? "");
                builder.SetAttribute(attributes.Description, obj.Description ?? "");
                builder.SetAttribute(attributes.Enlargement, obj.Enlargement ?? "");
                builder.SetAttribute(attributes.Document, obj.Document ?? "");
                builder.SetAttribute(attributes.Act, obj.Act.ToString() ?? "");
                builder.SetAttribute(attributes.Commit, obj.Commit ?? "");
                builder.SetAttribute(attributes.Statement, obj.Statement? 1 : 0);
            }
            catch (Exception)
            {
            }
        }

        public Guid GetIdFromLink(string link)
        {
            Guid id = Guid.Empty;

            if (string.IsNullOrEmpty(link) || link.Length < 47)
                return id;

            link = link.Remove(0, 11);

            if (link.Length > 36)
            {
                link = link.Remove(36);
            }

            id = Guid.Parse(link);

            return id;
        }

        public ColorsRow GetColor(TableRemarksModel remark)
        {
            if (remark.Statement)
            {
                switch (remark.Act)
                {
                    case Acts.FINALIZE:
                        return ColorsRow.GREEN;
                    case Acts.DEVELOP:
                        return ColorsRow.GREEN;
                    case Acts.EXCLUDE:
                        return ColorsRow.RED;
                    case Acts.DISMISS:
                        return ColorsRow.YELLOW;
                    default:
                        return ColorsRow.NONE;
                }
            }
            else
                return ColorsRow.NONE;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void DelObj(ProjectSection obj)
        {
            _modifer?.DeleteById(obj.Id);
            _modifer?.Apply();
        }

        public void AddObj(ProjectSection obj)
        {
            var builder = _modifer?.CreateById(obj.Id, obj.ParentId, _repository.GetType(obj.Type));
            if (builder != null && obj.Attributes.Any())
            {
                foreach (var attribute in obj.Attributes)
                {
                    builder.SetAttribute(attribute.Key, attribute.Value.ToString());
                }
            }
            _modifer?.Apply();
        }

        public void EditObj(ProjectSection obj)
        {
            var builder = _modifer?.EditById(obj.Id);
            if (builder != null && obj.Attributes.Any())
            {
                foreach (var attribute in obj.Attributes)
                {
                    builder.SetAttribute(attribute.Key, attribute.Value.ToString());
                }
            }
            _modifer?.Apply();
        }
    }
}
