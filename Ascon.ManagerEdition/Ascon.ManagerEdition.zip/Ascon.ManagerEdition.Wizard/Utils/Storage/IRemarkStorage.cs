﻿using Ascon.ManagerEdition.Wizard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ascon.ManagerEdition.Wizard.Utils.Storage
{
    public interface IRemarkStorage
    {
        void CreateRemark(TableRemarksModel obj);
        void DeleteRemark(TableRemarksModel obj);
        void EditRemark(TableRemarksModel obj);
        void DelObj(ProjectSection obj);
        void AddObj(ProjectSection obj);
        void EditObj(ProjectSection obj);
    }
}
