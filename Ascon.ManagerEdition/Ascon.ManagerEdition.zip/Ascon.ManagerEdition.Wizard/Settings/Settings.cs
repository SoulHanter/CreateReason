﻿using Ascon.ManagerEdition.Wizard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ascon.ManagerEdition.Wizard.Settings
{
    public class Settings
    {
        //стартовые объекты
        public List<PilotObjects> StartTypes { get; set; } = new List<PilotObjects>
        {
            new PilotObjects() {Type = "RedPD", AttributeCipher = "code", AttributeName = null},
            new PilotObjects() {Type = "RedRD", AttributeCipher = "code", AttributeName = null},
        };

        //группа выдачи прав на просмотр
        public List<string> Subdivisions { get; set; } = new List<string>
        {
            "Бюро ГИПов",
            "СПП Архитектуры"
        };

        //объект проект
        public PilotObjects Project { get; set; } = new PilotObjects
        {
            Type = "Project",
            AttributeCipher = "Project_code",
            AttributeName = "Project_name"
        };

        //объект папка замечаний
        public PilotObjects RemarkFolder { get; set; } = new PilotObjects
        {
            Type = "FolderZ",
            AttributeCipher = "GuidRed",
            AttributeName = "Name"
        };

        public PilotObjects DocumentForRedaction { get; set; } = new PilotObjects
        {
            Type = "Document",
            AttributeName = "Name",
            AttributeCipher = "code"
        };

        //замечания
        public RemarkFile RemarkFile { get; set; } = new RemarkFile
        {
            Type = "Z",
            FromUser = "FromUser",
            ToUser = "ToUser",
            Description = "Description",
            Enlargement = "Enlargement",
            Document = "Document",
            Act = "Act",
            Commit = "Commit",
            Statement = "Statement",
            DataCreate = "DataCreate",
            CurrentUser = "CurrentUser"
        };

        //от кого
        public List<Users> FromUser { get; set; } = new List<Users>
        {
            new Users {Name = "ГИП", FullName = "Задание ГИПа"},
            new Users {Name = "ЭХЗ", FullName = "Электрохимзащита от коррозии"},
            new Users {Name = "А", FullName = "Автоматизация"}
        };

        //кому
        public List<Users> ToUser { get; set; } = new List<Users>
        {
            new Users {Name = "ГИП", FullName = "Задание ГИПа"},
            new Users {Name = "ЭХЗ", FullName = "Электрохимзащита от коррозии"},
            new Users {Name = "А", FullName = "Автоматизация"}
        };

        public string GroupGipName { get; set; } = "Бюро ГИПов";

        public string GroupDesignerName { get; set; } = "СПП Архитектуры";

        public string NameRootRemarkFolder { get; set; } = "Папка с замечаниями";
    }
}
