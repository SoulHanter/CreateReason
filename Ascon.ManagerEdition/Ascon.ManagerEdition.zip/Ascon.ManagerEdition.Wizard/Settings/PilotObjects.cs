﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ascon.ManagerEdition.Wizard.Settings
{
    public class PilotObjects
    {
        public string Type { get; set; }
        public string AttributeName { get; set; }
        public string AttributeCipher { get; set; }
    }
}
