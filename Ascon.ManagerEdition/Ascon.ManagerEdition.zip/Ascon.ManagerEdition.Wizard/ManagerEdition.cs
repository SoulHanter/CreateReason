﻿using Ascon.ManagerEdition.Common.DICommon;
using Ascon.ManagerEdition.Wizard.Models;
using Ascon.ManagerEdition.Wizard.Settings;
using Ascon.ManagerEdition.Wizard.Utils;
using Ascon.ManagerEdition.Wizard.ViewModel;
using Ascon.ManagerEdition.Wizard.Views;
using Ascon.Pilot.SDK;
using Ascon.Pilot.SDK.Menu;
using Ascon.Pilot.Theme.ColorScheme;
using Ninject;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Ascon.ManagerEdition.Wizard
{
    [Export(typeof(IMenu<ObjectsViewContext>))]
    public class ManagerEdition : IMenu<ObjectsViewContext>
    {
        private IDataObject         _currentObject;
        private IObjectsRepository  _repository;
        private IObjectModifier     _modifier;
        private ISearchService      _search;
        private IFileProvider       _fileProvider;

        private readonly string[] commands     = { "OPEN_REDACTION", "LOOK_REDACTION", "CREATE_REDACTION", "TABLE_REMARKS"};
        private readonly string[] commandsName = { "Редакция", "Блокировка редакци", "Создать редакцию", "Таблица замечаний" };

        [ImportingConstructor]
        public ManagerEdition(IObjectsRepository repository, IObjectModifier modifier, IPilotDialogService dialogService, ISearchService search, IFileProvider fileProvider)
        {
            var accentColor = (Color)ColorConverter.ConvertFromString(dialogService.AccentColor);
            ColorScheme.Initialize(accentColor);

            _repository = repository;
            _modifier = modifier;
            _search = search;
            _fileProvider = fileProvider;

            InitializeObjects();
        }

        public void Build(IMenuBuilder builder, ObjectsViewContext context)
        {
            var settings = NinjectCommon.Kernel.Get<Settings.Settings>();
            _currentObject = context?.SelectedObjects
                                     .FirstOrDefault(x => settings.StartTypes.Any(t => x.Type.Name.Equals(t.Type)));
            if (_currentObject != null)
            {
                var menu = builder.AddItem(commands[0], 4).WithHeader(commandsName[0]);
                for (int i = 1; i < 4; i++)
                {
                    menu.WithSubmenu().AddItem(commands[i], i - 1).WithHeader(commandsName[i]);
                }
                NinjectCommon.Kernel.Rebind<IDataObject>().ToMethod(c => _currentObject).InSingletonScope();
            }
        }

        public void OnMenuItemClick(string name, ObjectsViewContext context)
        {
            switch (name)
            {
                case "LOOK_REDACTION": LookRedaction();
                    break;
                case "CREATE_REDACTION": CreateRedaction();
                    break;
                case "TABLE_REMARKS": TableRemarks();
                    break;
                default:
                    return;
            }
        }

        private void LookRedaction()
        {
            var settings = NinjectCommon.Kernel.Get<Settings.Settings>();

            var pilotRepository = NinjectCommon.Kernel.Get<PilotRepository>();

            //ограничение прав

            var accessRecord = _currentObject.Access2.Where(x => !x.Access.IsInherited).ToList();
            var accessRecordToUser = _currentObject.Access2.Where(x => _repository.GetCurrentPerson()
                                                                                  .Positions
                                                                                  .Select(p => p.Position)
                                                                                  .Contains(x.OrgUnitId)).ToList();
            //удаляем лишнее
            for (int i = 0; i < accessRecord.Count; i++)
            {
                _modifier.EditById(_currentObject.Id).RemoveAccessRights(accessRecord[i].OrgUnitId);
            }

            //добавление прав
            var types = settings.Subdivisions.Distinct().ToList();
            for (int i = 0; i < types.Count; i++)
            {
                var access = pilotRepository.GetAccessRecord(types[i], AccessLevel.View);
                pilotRepository.ChangedAccess(_currentObject.Id, access);
            }

            //удаляем у текущего
            for (int i = 0; i < accessRecordToUser.Count; i++)
            {
                _modifier.EditById(_currentObject.Id).RemoveAccessRights(accessRecordToUser[i].OrgUnitId);
            }
        }

        private void CreateRedaction()
        {
            NinjectCommon.Kernel.Rebind<CreateRedactionViewModel>().ToSelf().InSingletonScope();
            NinjectCommon.Kernel.Get<CreateRedactionView>().Show();
        }

        private void TableRemarks()
        {
            NinjectCommon.Kernel.Rebind<TableRemarksViewModel>().ToSelf().InSingletonScope();
            NinjectCommon.Kernel.Get<TableRemarksView>().Show();
        }

        private void InitializeObjects()
        {
            NinjectCommon.Kernel.Inject(this);

            NinjectCommon.Kernel.Bind<IObjectsRepository>().ToMethod(c => _repository).InSingletonScope();

            NinjectCommon.Kernel.Bind<IObjectModifier>().ToMethod(c => _modifier).InSingletonScope();

            NinjectCommon.Kernel.Bind<ISettingsFactory>().To<SettingsFactory>().InSingletonScope();

            NinjectCommon.Kernel.Bind<ISearchService>().ToMethod(c => _search).InSingletonScope();

            NinjectCommon.Kernel.Bind<IFileProvider>().ToMethod(c => _fileProvider).InSingletonScope();

            NinjectCommon.Kernel.Bind<Settings.Settings>().ToMethod(o => NinjectCommon.Kernel.Get<ISettingsFactory>().Read());
        }
    }
}
