﻿using Ascon.Pilot.SDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace Ascon.ManagerEdition.Wizard.Models
{
    public class File : IFile
    {
        public Guid Id { get; set; }

        public long Size { get; set; }

        public string Md5 { get; set; }

        public string Name { get; set; }

        public DateTime Modified { get; set; }

        public DateTime Created { get; set; }

        public DateTime Accessed { get; set; }

        public ReadOnlyCollection<ISignature> Signatures { get; set; }
    }
}
