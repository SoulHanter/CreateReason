﻿using Ascon.Pilot.SDK;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Ascon.ManagerEdition.Wizard.Models
{
    public class ProjectSection : ICloneable
    {
        public ProjectSection()
        {
            Id = Guid.NewGuid();
        }

        public Guid Id { get; set; }

        public Guid ParentId { get; set; }

        public string Name { get; set; }

        public int Type { get; set; }

        public ReadOnlyCollection<Guid> RelatedSourceFiles { get; set; }

        public ReadOnlyCollection<IFile> Files { get; set; }

        public FilesSnapshot ActualFileSnapshot { get; set; }

        public IDictionary<string, object> Attributes { get; set; } = new Dictionary<string, object>();

        public object Clone()
        {
            return this.MemberwiseClone();
        }

    }
}
