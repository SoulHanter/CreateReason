﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ascon.ManagerEdition.Wizard.Models
{
    public class RemarkFolderObject
    {
        public ProjectSection Object { get; set; }
        public ProjectSection parentObject { get; set; }
        public int Index { get; set; }
    }
}
