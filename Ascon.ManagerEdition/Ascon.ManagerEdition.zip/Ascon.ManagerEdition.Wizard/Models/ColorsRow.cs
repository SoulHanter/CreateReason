﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ascon.ManagerEdition.Wizard.Models
{
    public enum ColorsRow
    {
        GREEN,
        RED,
        YELLOW,
        NONE
    }
}
