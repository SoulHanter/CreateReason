﻿using Ascon.Pilot.SDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace Ascon.ManagerEdition.Wizard.Models
{
    public class FilesSnapshot : IFilesSnapshot
    {
        public DateTime Created { get; set; }

        public int CreatorId { get; set; }

        public string Reason { get; set; }

        public ReadOnlyCollection<IFile> Files { get; set; }
    }
}
