﻿using Ascon.Pilot.SDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ascon.ManagerEdition.Wizard.Models
{
    public class Signature : ISignature
    {
        public Guid Id  { get; set; }

        public Guid DatabaseId { get; set; }

        public int PositionId { get; set; }

        public string Role { get; set; }

        public string Sign { get; set; }

        public string RequestedSigner { get; set; }
    }
}
