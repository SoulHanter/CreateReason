﻿using Ascon.ManagerEdition.Wizard.ViewModel;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ascon.ManagerEdition.Wizard.Views
{
    /// <summary>
    /// Логика взаимодействия для CreateRowView.xaml
    /// </summary>
    public partial class CreateRowView : Window
    {
        public CreateRowView()
        {
            InitializeComponent();
        }

        [Inject]
        public CreateRowViewModel CreateRowViewModel
        {
            get => this.DataContext as CreateRowViewModel;
            set
            {
                this.DataContext = value;
                if (CreateRowViewModel.Close == null)
                    CreateRowViewModel.Close = this.Close;
            }
        }

        private void Document_Drop(object sender, DragEventArgs e)
        {
            var a = e.Data.GetData(DataFormats.Text);
            (this.DataContext as CreateRowViewModel).Document = a.ToString();
        }

        private void Enlargement_Drop(object sender, DragEventArgs e)
        {
            var a = e.Data.GetData(DataFormats.Text);
            (this.DataContext as CreateRowViewModel).Enlargement = a.ToString();
        }
    }
}
