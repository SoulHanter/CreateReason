﻿using Ascon.ManagerEdition.Common.DICommon;
using Ascon.ManagerEdition.Common.MVVMCommon.Command;
using Ascon.ManagerEdition.Common.PilotIceCommon.Observers;
using Ascon.ManagerEdition.Wizard.Models;
using Ascon.ManagerEdition.Wizard.Utils;
using Ascon.ManagerEdition.Wizard.Utils.Storage;
using Ascon.Pilot.SDK;
using Ninject;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Ascon.ManagerEdition.Wizard.ViewModel
{
    public class CreateRowViewModel : RemarkStorage
    {
        private Action _close;
        private TableRemarksModel _remark;
        private ObservableCollection<TableRemarksModel> _objects;
        private bool isCreate;

        private ICommand _ok;
        private ICommand _cancel;

        private string _document;
        private string _enlargement;

        public CreateRowViewModel(ObservableCollection<TableRemarksModel> objects, Guid parentId)
        {
            isCreate = true;            
            _objects = objects;
            _remark = new TableRemarksModel() { Act = Acts.FINALIZE, ParentId = parentId, Color = ColorsRow.NONE };
        }
        public CreateRowViewModel(TableRemarksModel remark, ObservableCollection<TableRemarksModel> objects, bool isEdit)
        {
            isCreate = false;
            IsEdit = isEdit;
            _objects = objects;
            _remark = remark.Clone() as TableRemarksModel;
            Document = _remark.Document;
            Enlargement = _remark.Enlargement;
        }

        public IEnumerable<string> GetFromUser => _settings.FromUser.Select(x => x.FullName).Distinct();
        public IEnumerable<string> GetToUser => _settings.ToUser.Select(x => x.FullName).Distinct();

        public TableRemarksModel Remark
        {
            get => _remark;
            set
            {
                _remark = value;
                NotifyPropertyChanged(nameof(Remark));
            }
        }

        public string Document
        {
            get => _document;
            set
            {
                var link = value;

                NinjectCommon.Kernel.Get<InfoLoader>().Load(objects =>
                {
                    var docs = objects.Where(o => o.ObjectStateInfo.State == ObjectState.Alive).Select(x => x.MapToProjectSection());

                    if (!docs.Any())
                        return;

                    _remark.Document = link;
                    _document = docs?.First()?.Name;

                    NotifyPropertyChanged(nameof(Document));
                   
                }, GetIdFromLink(link));                 
            }
        }

        public string Enlargement
        {
            get => _enlargement;
            set
            {
                var link = value;
                NinjectCommon.Kernel.Get<InfoLoader>().Load(objects =>
                {
                    var docs = objects.Where(o => o.ObjectStateInfo.State == ObjectState.Alive).Select(x => x.MapToProjectSection());
                    
                    if (!docs.Any())
                        return;

                    _remark.Enlargement = link;
                    _enlargement = docs?.First()?.Name;

                    NotifyPropertyChanged(nameof(Enlargement));

                }, GetIdFromLink(link));
            }
        }

        public Action Close
        {
            get { return _close; }
            set
            {
                _close = value;
                NotifyPropertyChanged(nameof(Close));
            }
        }

        public bool IsEdit { get; set; } = true;

        public ICommand Ok => _ok ??
            (_ok = new DelegateCommand(() =>
            {
                if (isCreate)
                {                   
                    if ( ((string.IsNullOrEmpty(_remark.FromUser) || string.IsNullOrEmpty(_remark.Document)) && _remark.Act != Acts.DEVELOP) ||
                         (string.IsNullOrEmpty(_remark.FromUser) && _remark.Act == Acts.DEVELOP))
                        System.Windows.MessageBox.Show("Не заполнены обязательные поля!");
                    else
                    {
                        _objects.Add(_remark);
                        CreateRemark(_remark);
                        Close();
                    }
                }
                else
                {
                    var item = _objects.Where(x => x.Id == _remark.Id).First();
                    _objects.Remove(item);
                    _remark.Color = GetColor(_remark);
                    _objects.Add(_remark);
                    EditRemark(_remark);
                    Close();
                }
            }));

        public ICommand Cancel => _cancel ??
            (_cancel = new DelegateCommand(() =>
            {
                Close();
            }));

        

        
    }
}
