﻿using Ascon.ManagerEdition.Common.DICommon;
using Ascon.ManagerEdition.Common.MVVMCommon.Command;
using Ascon.ManagerEdition.Common.PilotIceCommon.Observers;
using Ascon.ManagerEdition.Wizard.Models;
using Ascon.ManagerEdition.Wizard.Properties;
using Ascon.ManagerEdition.Wizard.Utils;
using Ascon.ManagerEdition.Wizard.Views;
using Ascon.Pilot.SDK;
using Ninject;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Ascon.ManagerEdition.Wizard.ViewModel
{
    public class TableRemarksViewModel : RemarkRepository
    {
        private object _currentItem;
        private ICommand _createRow;
        private ICommand _editRow;
        private ICommand _deleteRow;
        private ICommand _confirm;

        private bool _isGIP;

        public TableRemarksViewModel()
        {
            string _curentCipherName = _settings.StartTypes.FirstOrDefault(t => t.Type == NinjectCommon.Kernel.Get<IDataObject>().Type.Name)
                                             .AttributeCipher;

            string _curentCipherValue = _currentObject.Attributes[_curentCipherName].ToString();

            Title = $"Таблица замечаний к редакции {{{_curentCipherValue}}}";

            InitializeNameProject();
            InitializeDocument();
            
            _isGIP = IsGIP();
        }


        public int Top
        {
            get => SettingsForm.Default.Top;
            set
            {
                SettingsForm.Default.Top = value;
                SettingsForm.Default.Save();
                NotifyPropertyChanged(nameof(Top));
            }
        }
        public int Left
        {
            get => SettingsForm.Default.Left;
            set
            {
                SettingsForm.Default.Left = value;
                SettingsForm.Default.Save();
                NotifyPropertyChanged(nameof(Left));
            }
        }
        public int Width
        {
            get => SettingsForm.Default.Width;
            set
            {
                SettingsForm.Default.Width = value;
                SettingsForm.Default.Save();
                NotifyPropertyChanged(nameof(Width));
            }
        }
        public int Height
        {
            get => SettingsForm.Default.Height;
            set
            {
                SettingsForm.Default.Height = value;
                SettingsForm.Default.Save();
                NotifyPropertyChanged(nameof(Height));
            }
        }


        public string Title { get; set; }

        public ObservableCollection<TableRemarksModel> Remarks
        {
            get => _remarks;
            set
            {
                _remarks = value;
                NotifyPropertyChanged(nameof(Remarks));
            }
        }

        public ICommand CreateRow => _createRow ??
            (_createRow = new DelegateCommand(() =>
            {
                var vm = new CreateRowViewModel(_remarks, parentFolderRemark.Id);
                NinjectCommon.Kernel.Rebind<CreateRowViewModel>().ToMethod(o => vm).InSingletonScope();
                NinjectCommon.Kernel.Get<CreateRowView>().Show();
            }));

        public ICommand EditRow => _editRow ??
            (_editRow = new DelegateCommand(() =>
            {
                if (SelectedItem != null && (!(SelectedItem as TableRemarksModel).Statement || 
                                            ((SelectedItem as TableRemarksModel).Statement) && _isGIP))
                {
                    var vm = new CreateRowViewModel(SelectedItem as TableRemarksModel, _remarks, !(SelectedItem as TableRemarksModel).Statement);
                    NinjectCommon.Kernel.Rebind<CreateRowViewModel>().ToMethod(o => vm).InSingletonScope();
                    NinjectCommon.Kernel.Get<CreateRowView>().Show();
                }
            }));

        public ICommand DeleteRow => _deleteRow ??
            (_deleteRow = new DelegateCommand(() =>
            {
                if (SelectedItem != null && (!(SelectedItem as TableRemarksModel).Statement ||
                                            ((SelectedItem as TableRemarksModel).Statement) && _isGIP))
                {
                    CommandDelete(SelectedItem as TableRemarksModel);
                }
            }));

        public ICommand Confirm => _confirm ??
            (_confirm = new DelegateCommand(() =>
            {
                if (_remarks.Any() && _isGIP)
                {
                    foreach (var item in _remarks.Where(x => !x.Statement))
                    {
                        ComfirmEdit(item);
                        EditRemark(item);
                    }
                    Remarks = new ObservableCollection<TableRemarksModel>(_remarks);
                }
            }));

        public object SelectedItem
        {
            get => _currentItem;
            set
            {
                _currentItem = value;
                NotifyPropertyChanged(nameof(SelectedItem));
            }
        }

        private void ComfirmEdit(TableRemarksModel remark)
        {
            if (remark.Statement)
                return;

            remark.Statement = true;

            switch (remark.Act)
            {
                case Acts.FINALIZE: EditDocument(remark.Act, remark.Document);
                    break;
                case Acts.DEVELOP:
                    {
                        ProjectSection doc = new ProjectSection() { ParentId = _currentObject.Id };
                        var vm = new CreateDocumentViewModel(doc, x => { CreateDocument(x); });
                        NinjectCommon.Kernel.Rebind<CreateDocumentViewModel>().ToMethod(o => vm).InSingletonScope();
                        NinjectCommon.Kernel.Get<CreateDocumentView>().Show();                        
                       
                    }
                    break;
                case Acts.EXCLUDE: EditDocument(remark.Act, remark.Document);
                    break;
                default:
                    break;
            }
            remark.Color = GetColor(remark);
        }

        private void CommandDelete(TableRemarksModel remark)
        {
            switch (remark.Act)
            {
                case Acts.FINALIZE:
                    break;
                case Acts.DEVELOP:
                    DeleteRemark(remark);
                    _remarks.Remove(remark);
                    break;
                case Acts.EXCLUDE:
                    break;
                case Acts.DISMISS:
                    DeleteRemark(remark);
                    _remarks.Remove(remark);
                    break;
                default:
                    break;
            }
        }


        
    }


}
