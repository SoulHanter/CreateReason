﻿using Ascon.ManagerEdition.Common.DICommon;
using Ascon.ManagerEdition.Common.MVVMCommon.Command;
using Ascon.ManagerEdition.Common.PilotIceCommon.Observers;
using Ascon.ManagerEdition.Wizard.Models;
using Ascon.ManagerEdition.Wizard.Utils;
using Ascon.Pilot.SDK;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Ascon.ManagerEdition.Wizard.ViewModel
{
    public class CreateRedactionViewModel: ViewModelBase
    {
        private PilotRepository _pilotRepository = NinjectCommon.Kernel.Get<PilotRepository>();
        private IDataObject _currentObject = NinjectCommon.Kernel.Get<IDataObject>();
        private List<ProjectSection> _objects = new List<ProjectSection>();

        private char _lastChar;
        private string _curentCipherName;
        private string _curentCipherValue;
        private Guid _parentId;

        private ICommand _createdRedaction;
        private Action _close;        

        public CreateRedactionViewModel()
        {
            var _settings = NinjectCommon.Kernel.Get<Settings.Settings>();

            _curentCipherName = _settings.StartTypes.FirstOrDefault(t => t.Type == _currentObject.Type.Name)
                                             .AttributeCipher;

            _curentCipherValue = _currentObject.Attributes[_curentCipherName].ToString();

            _lastChar = _curentCipherValue[0];

            _parentId = _currentObject.ParentId;

            ActionCreateP = _lastChar.Equals('P');
            ActionCreateA = _lastChar.Equals('А') || _lastChar.Equals('P');
            ActionCreateI = _lastChar.Equals('И') || _lastChar.Equals('А');
        }

        public bool ActionCreateP { get; private set; } = false;
        public bool ActionCreateA { get; private set; } = false;
        public bool ActionCreateI { get; private set; } = false;

        public Action Close
        {
            get { return _close; }
            set
            {
                _close = value;
                NotifyPropertyChanged(nameof(Close));
            }
        }

        public ICommand CreatedRedaction => _createdRedaction ??
            (_createdRedaction = new DelegateCommandAsync<string>(async x => 
            {
                switch (x)
                {
                    case "createP":
                        _curentCipherValue = IncrementChiperValue(_curentCipherValue);
                        break;
                    case "createA":
                        _curentCipherValue = _lastChar.Equals('А') ? IncrementChiperValue(_curentCipherValue) : "А00";
                        break;
                    case "createI":
                        _curentCipherValue = _lastChar.Equals('И') ? IncrementChiperValue(_curentCipherValue) : "И00";
                        break;
                    default:
                        _curentCipherValue = null;
                        break;
                }

                if (_curentCipherValue != null)
                {
                    await AppendObjects(_curentCipherValue);
                    Close();
                }
            }));     


        private string IncrementChiperValue(string source)
        {
            if (source.Length < 3)
                return null;

            string cipher = source;            
            try
            {
                int intCihper = int.Parse(cipher.Remove(0, 1));
                intCihper++;

                if (intCihper.ToString().Length == 1)
                    return $"{source[0]}0{intCihper}";
                else
                    return $"{source[0]}{intCihper}";

            }
            catch (Exception)
            {
                return null;
            }
        }

        private Task AppendObjects(string curentCipherValue)
        {
            return Task.Factory.StartNew(() =>
            {
                var newObj = _pilotRepository.CreateNewRedaction(_currentObject.ParentId, _currentObject.Type, _curentCipherName, curentCipherValue);

                if (newObj == null)
                    return;

                //добавление прав
                var types = NinjectCommon.Kernel.Get<Settings.Settings>().Subdivisions.Distinct().ToList();
                for (int i = 0; i < types.Count; i++)
                {
                    var access = _pilotRepository.GetAccessRecord(types[i], AccessLevel.View);
                    _pilotRepository.ChangedAccess(newObj.Id, access);
                }

                NinjectCommon.Kernel.Get<IObjectsLoader>("child").Load(objects =>
                {
                    _objects = objects.Where(t => t.Id != _currentObject.Id)
                                      .Select(o => o.MapToProjectSection()).ToList();                    
                    Initialize(newObj);

                }, type => true,
                   _currentObject.Id);
            });
        }

        private void Initialize(IDataObject obj)
        {
            var items = _objects.ChangedGuid(_currentObject.Id, obj.Id);
            _pilotRepository.CreateAsync(items, obj.Id);
        }

    }
}
